from flask import flask
from flask_sqlalchemy import SQLAlchemy
import config

app=flask(__name__)
